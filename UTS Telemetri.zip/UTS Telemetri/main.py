import sys
import serial
import serial.tools.list_ports
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from datetime import datetime


class SerialReader(QThread):

    data_received = pyqtSignal(str)

    def __init__(self, port):
        super().__init__()
        self.port = port
        self.running = True

    def run(self):

        ser = serial.Serial(self.port,115200)

        while self.running:

            if ser.in_waiting:
                data = ser.readline().decode().strip()
                self.data_received.emit(data)

        ser.close()


class Window(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("IoT Telemetry Monitoring")
        self.setGeometry(200,100,900,550)

        mainLayout = QVBoxLayout()

        title = QLabel("IoT Telemetry Monitoring System")
        title.setStyleSheet("font-size:22px;font-weight:bold;color:#00E5FF")
        title.setAlignment(Qt.AlignCenter)

        mainLayout.addWidget(title)

        # =====================
        # PORT SECTION
        # =====================

        portLayout = QHBoxLayout()

        self.portBox = QComboBox()
        self.refreshPorts()

        self.connectBtn = QPushButton("Connect")

        self.connectBtn.clicked.connect(self.connectSerial)

        portLayout.addWidget(QLabel("Serial Port"))
        portLayout.addWidget(self.portBox)
        portLayout.addWidget(self.connectBtn)

        mainLayout.addLayout(portLayout)

        # =====================
        # SENSOR CARDS
        # =====================

        cardLayout = QHBoxLayout()

        self.tempLabel = self.createCard("Temperature","-- °C")
        self.humLabel = self.createCard("Humidity","-- %")
        self.soilLabel = self.createCard("Soil Moisture","--")
        self.ldrLabel = self.createCard("LDR Light","--")

        cardLayout.addWidget(self.tempLabel)
        cardLayout.addWidget(self.humLabel)
        cardLayout.addWidget(self.soilLabel)
        cardLayout.addWidget(self.ldrLabel)

        mainLayout.addLayout(cardLayout)

        # =====================
        # TABLE
        # =====================

        self.table = QTableWidget()

        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(
            ["Node ID","Time","Temperature","Humidity","Soil","LDR"]
        )

        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        mainLayout.addWidget(self.table)

        container = QWidget()
        container.setLayout(mainLayout)

        self.setCentralWidget(container)

        self.setStyleSheet("""
        QMainWindow{
            background-color:#1e1e2f;
            color:white;
        }

        QLabel{
            color:white;
            font-size:14px;
        }

        QComboBox{
            padding:5px;
            background:#2b2b40;
            color:white;
        }

        QPushButton{
            background:#00E5FF;
            border:none;
            padding:6px 15px;
            font-weight:bold;
        }

        QPushButton:hover{
            background:#00bcd4;
        }

        QTableWidget{
            background:#2b2b40;
            color:white;
            gridline-color:#444;
        }

        QHeaderView::section{
            background:#00E5FF;
            color:black;
            font-weight:bold;
        }
        """)

    # =====================
    # SENSOR CARD
    # =====================

    def createCard(self,title,value):

        frame = QFrame()
        frame.setStyleSheet("""
        QFrame{
            background:#2b2b40;
            border-radius:10px;
            padding:15px;
        }
        """)

        layout = QVBoxLayout()

        titleLabel = QLabel(title)
        titleLabel.setAlignment(Qt.AlignCenter)

        valueLabel = QLabel(value)
        valueLabel.setAlignment(Qt.AlignCenter)
        valueLabel.setStyleSheet("font-size:24px;font-weight:bold;color:#00E5FF")

        layout.addWidget(titleLabel)
        layout.addWidget(valueLabel)

        frame.setLayout(layout)

        frame.valueLabel = valueLabel

        return frame

    # =====================

    def refreshPorts(self):

        ports = serial.tools.list_ports.comports()

        for port in ports:
            self.portBox.addItem(port.device)

    # =====================

    def connectSerial(self):

        port = self.portBox.currentText()

        self.thread = SerialReader(port)
        self.thread.data_received.connect(self.processData)
        self.thread.start()

        self.connectBtn.setEnabled(False)

    # =====================

    def processData(self,data):

        try:

            parts = data.split(";")

            temp = parts[0].split("=")[1]
            hum = parts[1].split("=")[1]
            soil = parts[2].split("=")[1]
            ldr = parts[3].split("=")[1]

            self.tempLabel.valueLabel.setText(temp+" °C")
            self.humLabel.valueLabel.setText(hum+" %")
            self.soilLabel.valueLabel.setText(soil)
            self.ldrLabel.valueLabel.setText(ldr)

            row = self.table.rowCount()
            self.table.insertRow(row)

            time = datetime.now().strftime("%H:%M:%S")

            self.table.setItem(row,0,QTableWidgetItem("Node1"))
            self.table.setItem(row,1,QTableWidgetItem(time))
            self.table.setItem(row,2,QTableWidgetItem(temp))
            self.table.setItem(row,3,QTableWidgetItem(hum))
            self.table.setItem(row,4,QTableWidgetItem(soil))
            self.table.setItem(row,5,QTableWidgetItem(ldr))

        except:
            pass


app = QApplication(sys.argv)

window = Window()
window.show()

sys.exit(app.exec_())